import requests
import json
import random 
import mariadb
import os
import zipfile
import time
from urllib.parse import urlparse
import urllib.parse
import traceback

DISCORD_WEBHOOK = "https://discord.com/api/webhooks/EXAMPLE/EXAMPLE"
DB_PASSWORD = "EXAMPLE"

def refreshToken():
   otoken = open("token.txt", "r").read()
   r = requests.post("https://20ca2.playfabapi.com/Authentication/GetEntityToken", headers={"x-entitytoken":otoken, "Accept-Language":"en-US" ,"Content-Type":"application/json"})
   ntoken = json.loads(r.content)["data"]["EntityToken"]
   open("token.txt", "w").write(ntoken)
   return ntoken
   
def getEntityToken():
    return refreshToken()

def TellMe(message):
    requests.post(DISCORD_WEBHOOK, json={"content":"<@EXAMPLE>"message})

def TellMeLessImportant(message):
    requests.post(DISCORD_WEBHOOK, json={"content":message})

conn = None
cur = None

def DbConnect():
    global conn
    global cur
    conn = mariadb.connect(
        user="root",
        password=DB_PASSWORD,
        host="127.0.0.1",
        port=3306,
        database="tpb"
    )
    cur = conn.cursor()

def buyItem(itemId, expectedPrice, currency):
    return requests.post("https://20ca2.playfabapi.com/Catalog/PurchaseItemById", 
    json={"Currencies":
    [{"CurrencyId":currency,"ExpectedPrice":expectedPrice}],
    "ItemId":itemId,
    "Quantity":1},
    headers={"x-entitytoken":ENTITYTOKEN, 
    "Content-Type":"application/json"}).content


def getItemIdList():
    itemIds = []
    cur.execute("SELECT Id FROM contents")
    idlist = cur.fetchall()
    for iid in idlist:
        itemIds.append(iid[0])
    return itemIds
    
def ReadZipData(zipData):
    open("tmp.zip", "wb").write(zipData)
    ZipInfo = []
    with zipfile.ZipFile("tmp.zip","r") as outerZip:
        for outZFileName in outerZip.namelist():
            if outZFileName.endswith(".zip"):
                with outerZip.open(outZFileName) as outZFile:
                    with zipfile.ZipFile(outZFile, "r") as innerZip:
                        Modules = []
                        FileList = []
                        KeyId = ""
                        
                        with innerZip.open('manifest.json') as manifest:
                            mJobj = json.loads(manifest.read())
                            KeyId = mJobj['header']['uuid']
                            
                            for Module in mJobj['modules']:                                   
                                Modules.append(Module['type'])

                        for InnerZipName in innerZip.namelist():
                            with innerZip.open(InnerZipName) as file:
                                FileList.append({"File": InnerZipName, "Size":len(file.read())})
                        
                        ZipInfo.append((Modules, outZFileName, KeyId, FileList))
    return ZipInfo
                              
        
    
def archiveOrg(url):
    while True:
        try:
            print("Archive.Org-ing: "+url)
            r = requests.post("https://web.archive.org/save/"+url, data={"url": url, "capture_all": "on"})
            if r.status_code == 200:
                return r
            else:
                time.sleep(10)
                continue
        except:
            continue
        
def tryGet(url):
    while True:
        try:
            return requests.get(url, headers={"User-Agent":"cpprestsdk/2.9.0"})
        except:
            continue

while True:
    # Refresh Entity Token
    
    TellMeLessImportant("Starting search for new Marketplace Contents...") 
    
    ENTITYTOKEN = getEntityToken()
    DbConnect()
    PillagedItems = getItemIdList()
    PillageTheseItems = []

    NewContents = 0
    ItemsBrought = 0
    KeysFound = 0

    # Get new items
    skip = 0
    retry_counter = 0
    while skip < 10000:
        try:
            r = requests.post("https://20ca2.playfabapi.com/Catalog/Search", 
                                json={"count":True,
                                    "filter":"",
                                    "orderBy":"creationDate desc",
                                    "select":"contents",
                                    "skip":skip,
                                    "top":300},
                                headers={"x-entitytoken":ENTITYTOKEN})
            
            jobj = json.loads(r.content)
            
            if r.status_code == 429:
                    time.sleep(jobj["retryAfterSeconds"])
                    continue
            
            for itm in jobj["data"]["Items"]:
                if len(itm['Contents']) <= 0:
                    continue
                    
                if len(itm['Contents']) >= 1:
                    if not itm['Contents'][0]["Url"].lower().endswith(".zip"):
                        continue
                        
                if PillagedItems.count(itm["Id"]) > 0:
                    continue
                else:
                    PillageTheseItems.append(itm["Id"])
                    print("Not Found: " +itm["Id"] + " " +itm["Title"]['NEUTRAL'])
                    print(itm['Contents'])
                
            skip += 300
        except Exception as e:
            retry_counter += 1
            if retry_counter > 20:
                skip += 300
                retry_counter = 0
                TellMe("UHHH IT BROKE..\n```"+traceback.print_exc()+"```")
            continue


    DbConnect()
    NewUrls = []
    i = 0

    retry_counter = 0
    while i < len(PillageTheseItems):
        try:
            ContentId = PillageTheseItems[i]
            r = requests.post("https://20ca2.playfabapi.com/Catalog/GetPublishedItem", 
                                json={"ItemId": ContentId},
                                headers={"x-entitytoken":ENTITYTOKEN})
            
            if not os.path.exists("Metadata/"+ContentId+".json"):
                open("Metadata/"+ContentId+".json", "wb").write(r.content)
            
            jobj = json.loads(r.content)
            
            if r.status_code == 429:
                    time.sleep(jobj["retryAfterSeconds"])
                    continue
            Item = jobj['data']['Item']
            
            langs = list(Item['Title'].keys())
            if len(langs) > 0:
                Title = Item['Title'][langs[0]]
            else:
                continue
                
            langs = list(Item['Description'].keys())
            if len(langs) > 0:
                Description = Item['Description'][langs[0]]
            else:
                continue
            
            Tags = Item['Tags']
            
            Contents = Item["Contents"]
            
            ContentType = ""
            
            ContentSize = 0
            
            for Tag in Tags:
                if Tag == "resourcepack":
                    if not ContentType == "" and not ContentType == "RESOURCEPACK":
                        ContentType = "MIXED"
                    else:
                        ContentType = "RESOURCEPACK"
                       
                if Tag == "has_skinpack" or Tag == "skinpack":
                    if not ContentType == "" and not ContentType == "SKINPACK":
                        ContentType = "MIXED"
                    else:
                        ContentType = "SKINPACK"
                
                if Tag == "worldtemplate":
                    if not ContentType == "" and not ContentType == "WORLD":
                        ContentType = "MIXED"
                    else:
                        ContentType = "WORLD"
                        
                if Tag == "mashup":
                    ContentType = "MIXED"

                cur.execute("INSERT INTO contentstags VALUES(?,?)", (ContentId, Tag))
            
            if len(Contents) <= 0:
                i+=1
                continue
            
            continu = False
            
            for Content in Contents:
                Url = Content["Url"]
                UrlId = Content["Id"]
                UrlType = Content["Type"]
                UrParse = urlparse(Url)
                ZipName = os.path.basename(UrParse.path)

                
                if Url.lower().endswith(".zip"):
                    cur.execute("INSERT INTO contentsurls VALUES(?,?,?,?)", (ContentId, UrlId, UrlType, Url))
                    
                    r = tryGet(Url)
                    
                    if r.content == b"Not Found":
                        print("NOT FOUND: "+Url)
                        continue
                    
                    if not r.status_code == 200:
                        print("ERR: "+str(r.status_code))
                        continue
                        
                    try:
                        ZipInfo = ReadZipData(r.content)
                    except:
                        continue
                        
                    if len(ZipInfo) <= 0:
                        print("Zip Contained no packs? interesting?"+Url)
                        continue
          
                    for ZInfo in ZipInfo:
                        Modules, InnerZipName, KeyId, FileList = ZInfo
                        
                        ContentSize += len(r.content)
                        
                        for File in FileList:
                            cur.execute("INSERT INTO contentsfiles VALUES(?,?,?,?,?,?)", (ContentId, KeyId, ZipName, InnerZipName, urllib.parse.quote_plus(File["File"]), File["Size"]))
                        
                        ContentKey = "UNKNOWN"
                        
                        if UrlType == "skinbinary" or UrlType == "personabinary":
                            KeysFound += 1
                            ContentKey = "s5s5ejuDru4uchuF2drUFuthaspAbepE"

                        if UrlType == "skinbinary":
                            if not ContentType == "" and not ContentType == "SKINPACK":
                                ContentType = "MIXED"
                            else:
                                ContentType = "SKINPACK"
                                
                        if UrlType == "personabinary":
                            if not ContentType == "" and not ContentType == "PERSONA":
                                ContentType = "MIXED"
                            else:
                                ContentType = "PERSONA"
                                
                        KeyType = ""
                        for Module in Modules:
                            if Module == "resourcepack":
                                if not ContentType == "" and not ContentType == "RESOURCEPACK":
                                    ContentType = "MIXED"
                                else:
                                    ContentType = "RESOURCEPACK"
                               
                            if Module == "skinpack":
                                if not ContentType == "" and not ContentType == "SKINPACK":
                                    ContentType = "MIXED"
                                else:
                                    ContentType = "SKINPACK"
                        
                            if Module == "worldtemplate":
                                if not ContentType == "" and not ContentType == "WORLD":
                                    ContentType = "MIXED"
                                else:
                                    ContentType = "WORLD"
                                    
                            KeyType = Module
                            cur.execute("INSERT INTO contentsmodules VALUES(?,?,?,?,?,?)", (ContentId, KeyId, UrlId, ZipName, InnerZipName, Module))
                        
                        if KeyType == "worldtemplate":
                            KeyType = "world_template"
                            
                        if KeyType == "skinpack":
                            KeyType = "skin_pack"

                        cur.execute("INSERT INTO contentskeys VALUES(?,?,?,?)", (ContentId, KeyId, KeyType, ContentKey))
                        
                        
                        NewUrls.append(Url)
                
                else:
                    conn.rollback()
                    print("NOT ZIP "+Url)
                    continu = True
                    break
                    
                    
            if continu or ContentSize <= 0:
                conn.rollback()
                print(ContentId + " " + Title +"(SKIP)")
                i+=1
                continue
            
            if ContentType == "":
                ContentType = "UNKNOWN"

            print(ContentId + " " + Title)
            NewContents += 1 
            cur.execute("INSERT INTO contents VALUES(?,?,?,?,?,?)", (ContentId, urllib.parse.quote_plus(Title), urllib.parse.quote_plus(Description), ContentType, int(time.time()), ContentSize))
            conn.commit()
            
            # Buy it if its free (lol)
            try:
                if not Item["Price"] == None:
                    if not Item["Price"]["Prices"] == None:
                        for PriceEntry in Item["Price"]["Prices"]:
                            for AmountInfo in PriceEntry["Amounts"]:
                                CurrencyId = AmountInfo["CurrencyId"]
                                Amount = AmountInfo["Amount"]
                                if Amount <= 0:
                                    ItemsBrought += 1
                                    print(buyItem(ContentId, Amount, CurrencyId))
                                    break
                        
            except KeyError:
                print(buyItem(ContentId, 0, "ecd19d3c-7635-402c-a185-eb11cb6c6946"))
                pass
                
            i+=1
        except Exception as e:
            retry_counter += 1
            if retry_counter > 20:
                conn.rollback()
                i += 1
                retry_counter = 0
                TellMe("UHHH IT BROKE..\n```"+str(e)+"```")
            continue
    TellMeLessImportant("Results: \n\tNew Contents: "+str(NewContents)+"\n\tItems Brought: "+str(ItemsBrought)+"\n\tKeys Found: "+str(KeysFound))     
    time.sleep(3600 * 12)
