﻿namespace BlackMarketplace
{
    partial class DownloadForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DownloadForm));
            this.sync = new System.Windows.Forms.Button();
            this.dl = new System.Windows.Forms.Button();
            this.progress = new System.Windows.Forms.ProgressBar();
            this.search = new System.Windows.Forms.TextBox();
            this.options = new System.Windows.Forms.DataGridView();
            this.Download = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UUID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.options)).BeginInit();
            this.SuspendLayout();
            // 
            // sync
            // 
            this.sync.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.sync.Location = new System.Drawing.Point(999, 616);
            this.sync.Name = "sync";
            this.sync.Size = new System.Drawing.Size(49, 23);
            this.sync.TabIndex = 1;
            this.sync.Text = "Sync";
            this.sync.UseVisualStyleBackColor = true;
            this.sync.Click += new System.EventHandler(this.sync_Click);
            // 
            // dl
            // 
            this.dl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dl.Location = new System.Drawing.Point(12, 616);
            this.dl.Name = "dl";
            this.dl.Size = new System.Drawing.Size(75, 23);
            this.dl.TabIndex = 2;
            this.dl.Text = "Download";
            this.dl.UseVisualStyleBackColor = true;
            this.dl.Click += new System.EventHandler(this.dl_Click);
            // 
            // progress
            // 
            this.progress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progress.Location = new System.Drawing.Point(146, 558);
            this.progress.Name = "progress";
            this.progress.Size = new System.Drawing.Size(902, 23);
            this.progress.TabIndex = 3;
            // 
            // search
            // 
            this.search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.search.Location = new System.Drawing.Point(12, 587);
            this.search.Name = "search";
            this.search.PlaceholderText = "Search";
            this.search.Size = new System.Drawing.Size(1036, 23);
            this.search.TabIndex = 4;
            this.search.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.search_KeyPress);
            // 
            // options
            // 
            this.options.AllowUserToAddRows = false;
            this.options.AllowUserToDeleteRows = false;
            this.options.AllowUserToResizeRows = false;
            this.options.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.options.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.options.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Download,
            this.Title,
            this.Description,
            this.UUID});
            this.options.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.options.Location = new System.Drawing.Point(0, 0);
            this.options.Name = "options";
            this.options.RowHeadersVisible = false;
            this.options.RowTemplate.Height = 25;
            this.options.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.options.Size = new System.Drawing.Size(1060, 552);
            this.options.TabIndex = 5;
            this.options.Scroll += new System.Windows.Forms.ScrollEventHandler(this.options_Scroll);
            this.options.SelectionChanged += new System.EventHandler(this.options_SelectionChanged);
            // 
            // Download
            // 
            this.Download.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Download.HeaderText = "DL";
            this.Download.MinimumWidth = 30;
            this.Download.Name = "Download";
            this.Download.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Download.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Download.ToolTipText = "Download";
            this.Download.Width = 30;
            // 
            // Title
            // 
            this.Title.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Title.HeaderText = "Title";
            this.Title.Name = "Title";
            this.Title.ReadOnly = true;
            this.Title.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Description
            // 
            this.Description.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // UUID
            // 
            this.UUID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.UUID.HeaderText = "UUID";
            this.UUID.MinimumWidth = 230;
            this.UUID.Name = "UUID";
            this.UUID.ReadOnly = true;
            this.UUID.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.UUID.Width = 230;
            // 
            // status
            // 
            this.status.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.status.BackColor = System.Drawing.Color.Teal;
            this.status.Location = new System.Drawing.Point(4, 558);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(136, 23);
            this.status.TabIndex = 6;
            this.status.Text = "Waiting ...";
            this.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DownloadForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 651);
            this.Controls.Add(this.status);
            this.Controls.Add(this.options);
            this.Controls.Add(this.search);
            this.Controls.Add(this.progress);
            this.Controls.Add(this.dl);
            this.Controls.Add(this.sync);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DownloadForm";
            this.Text = "Download";
            this.Load += new System.EventHandler(this.DownloadForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.options)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button sync;
        private Button dl;
        private ProgressBar progress;
        private TextBox search;
        private DataGridView options;
        private Label status;
        private DataGridViewCheckBoxColumn Download;
        private DataGridViewTextBoxColumn Title;
        private DataGridViewTextBoxColumn Description;
        private DataGridViewTextBoxColumn UUID;
    }
}