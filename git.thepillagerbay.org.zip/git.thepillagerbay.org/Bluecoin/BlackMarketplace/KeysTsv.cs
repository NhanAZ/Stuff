﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using McCrypt;

namespace BlackMarketplace
{
    public class KeysTsv
    {
        private static List<KeysTsv> marketplaceItems = new List<KeysTsv>();
        public static KeysTsv[] Items
        {
            get
            {
                return marketplaceItems.ToArray();
            }
        }

        public static KeysTsv[] LookupKey(string contentId)
        {
            List<KeysTsv> keyList = new List<KeysTsv>();
            foreach (KeysTsv key in KeysTsv.Items)
                if (key.ContentId == contentId)
                    keyList.Add(key);
            return keyList.ToArray();
        }
        public static void ClearKeysList()
        {
            marketplaceItems.Clear();
        }
        public KeysTsv(string contentId, string keyId, string keyType, string keyData)
        {
            this.ContentId = contentId;
            this.KeyId = keyId;
            this.KeyType = keyType;
            this.KeyData = keyData;
            if (keyData != "UNKNOWN") {
                marketplaceItems.Add(this);
            }

        }

        public string ContentId;
        public string KeyId;
        public string KeyType;
        public string KeyData;
    }
}
