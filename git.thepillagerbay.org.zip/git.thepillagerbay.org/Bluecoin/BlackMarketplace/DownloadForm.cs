using McCrypt;
using Newtonsoft.Json.Linq;
using System.IO.Compression;
using System.Text;

namespace BlackMarketplace
{
    public partial class DownloadForm : Form
    {
        public DownloadForm()
        {
            InitializeComponent();
        }


        private string _searchFor = "";
        private string _lastSearch = "";
        private int _skip = 0;
        private bool _searching = false;
        private void LoadDb()
        {
            if (File.Exists(Path.Combine(Config.DataFolder, "keys.tsv")))
            {
                KeysTsv.ClearKeysList();
                string[] keysList = File.ReadAllLines(Path.Combine(Config.DataFolder, "keys.tsv"));

                foreach (string key in keysList.Skip(1))
                {
                    string[] kvpairs = key.Split('\t');
                    KeysTsv ky = new KeysTsv(kvpairs[0], kvpairs[1], kvpairs[2], kvpairs[3]);
                }
            }
        }

        private void SubmitMinecraftKeys()
        {
            string uploadLocation = Config.GetConfValue("KeyUploadUrl");
            if(uploadLocation != null)
            {
                string LocalAppdata = Environment.GetEnvironmentVariable("LOCALAPPDATA");
                string MinecraftFolder = Path.Combine(LocalAppdata, "Packages", "Microsoft.MinecraftUWP_8wekyb3d8bbwe");
                string LocalState = Path.Combine(MinecraftFolder, "LocalState");
                string OptionsTxt = Path.Combine(LocalState, "games", "com.mojang", "minecraftpe", "options.txt");

                if (File.Exists(OptionsTxt))
                    McCrypt.Keys.ReadOptionsTxt(OptionsTxt);

                if (Directory.Exists(LocalState))
                {
                    string[] entFiles = Directory.GetFiles(LocalState, "*.ent", SearchOption.TopDirectoryOnly);

                    foreach (string entFile in entFiles)
                    {
                        McCrypt.Keys.ReadEntitlementFile(entFile);
                    }
                }
                string keysJson = McCrypt.Keys.ExportKeysJson();
                McClient wc = new McClient();
                wc.Headers.Set("Content-Type", "application/json");
                wc.UploadString(uploadLocation, keysJson);
                wc.Dispose();
            }
        }

        private void DownloadForm_Load(object sender, EventArgs e)
        {
            search.ReadOnly = true;
            Task.Run(() =>
            {
                try
                {
                    Invoke(() => { status.Text = "Loading keys.tsv..."; });
                    LoadDb();
                    Invoke(() => { status.Text = "Logging into PlayFab..."; });
                    PlayFab.PullEntityTokenOutOfMyAss();
                    DoSearch();
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                try
                {
                    Invoke(() => { status.Text = "Submitting keys..."; });
                    SubmitMinecraftKeys();
                    Invoke(() => { status.Text = "Waiting..."; });
                }
                catch (Exception) { };
            });

        }

        private void ClearUnchecked()
        {
            for (int i = options.Rows.Count - 1; i >= 0; i--)
            {
                if (!(bool)options.Rows[i].Cells[0].FormattedValue)
                {
                    options.Rows.RemoveAt(i);
                }
            }
        }

        private void DoSearch()
        {
            if (_searching)
                return;

            Invoke(() => { status.Text = "Searching..."; });
            _searching = true;
            Invoke(() => { search.ReadOnly = true; });
            string query = _searchFor;

            // Is this a new search?
            if (_lastSearch != query)
            {
                Invoke(() => { ClearUnchecked(); });
                _skip = 0;
                _lastSearch = query;
            }

            dynamic results = PlayFab.Search(query, "(contentType eq 'MarketplaceDurableCatalog_V1.2')", _skip);
            _skip += 300;
            if (results == null)
            {
                _searching = false;
                Invoke(() => { status.Text = "Waiting..."; });
                Invoke(() => { search.ReadOnly = false; });
                return;
            }
            if (results.Items == null)
            {
                _searching = false;
                Invoke(() => { status.Text = "Waiting..."; });
                Invoke(() => { search.ReadOnly = false; });
                return;
            }

            Invoke(() => {
                foreach (dynamic result in results.Items)
                {
                    if (result.Title == null)
                        continue;
                    if (result.Description == null)
                        continue;
                    if (result.Id == null)
                        continue;


                    // Do we have keys for this pack?
                    if (KeysTsv.LookupKey(result.Id.ToString()).Length <= 0)
                    {

                        // if we dont have a key, check does it contain a skinpack? 
                        if (result.DisplayProperties != null)
                        {
                            if (result.DisplayProperties.packIdentity != null)
                            {
                                foreach (dynamic packId in result.DisplayProperties.packIdentity)
                                {

                                    if (packId.type.ToString() == "skinpack" || packId.type.ToString() == "skin_pack")
                                        new KeysTsv(result.Id.ToString(), packId.uuid.ToString(), "skin_pack", "s5s5ejuDru4uchuF2drUFuthaspAbepE"); // Use standard skinpacks key

                                    if (packId.type.ToString().StartsWith("persona"))
                                        new KeysTsv(result.Id.ToString(), packId.uuid.ToString(), packId.type.ToString(), "s5s5ejuDru4uchuF2drUFuthaspAbepE"); // Use standard persona key

                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }


                    JObject resTitle = result.Title;
                    JObject resDesc = result.Description;

                    if (resTitle.First == null)
                        continue;

                    if (resDesc.First == null)
                        continue;

                    if (resTitle.First.First == null)
                        continue;

                    if (resDesc.First.First == null)
                        continue;

                    string title = resTitle.First.First.ToString();
                    string desc = resDesc.First.First.ToString();
                    string uuid = result.Id;

                    // Mojang broke something with the searches i swear ...
                    if (!title.ToLower().Contains(query.ToLower()))
                        continue;

                    options.Rows.Add(false, title, desc, uuid);
                }
            });

            Invoke(() => { status.Text = "Waiting..."; });
            Invoke(() => { search.ReadOnly = false; });
            _searching = false;
            return;
        }

        private void DeleteTempFiles()
        {
            string downloadFolder = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "BlackMarketplace");
            Directory.Delete(downloadFolder, true);
        }
        private string CreateTemporaryFile()
        {

            string downloadFolder = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "BlackMarketplace", Guid.NewGuid().ToString());
            return downloadFolder;
        }
        private string CreateTemporaryFolder()
        {
            
            string downloadFolder = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "BlackMarketplace", Guid.NewGuid().ToString());
            Directory.CreateDirectory(downloadFolder);
            return downloadFolder;
        }
        private void sync_Click(object sender, EventArgs e)
        {
            SyncForm syncForm = new SyncForm();
            syncForm.ShowDialog();
        }

        public static string EscapeFilename(string filename)
        {
            return filename.Replace("/", "_").Replace("\\", "_").Replace(":", "_").Replace("?", "_").Replace("*", "_").Replace("<", "_").Replace(">", "_").Replace("|", "_");
        }

        private void DownloadSelected()
        {
            Invoke(() => { dl.Enabled = false; });
            // Find all uuids of selected products.
            List<string> uuidList = new List<string>();
            foreach (DataGridViewRow row in options.Rows)
            {
                if ((bool)row.Cells[0].FormattedValue)
                {
                    uuidList.Add(row.Cells[3].Value.ToString());
                    Invoke(() => { row.Cells[0].Value = false; });
                }
            }


            // Lookup URL for every uuid found.
            List<string> urlList = new List<string>();
            for(int i = 0; i < uuidList.Count; i++)
            {
                Invoke(() => { status.Text = "Getting URL " + (i+1).ToString() + "/" + uuidList.Count.ToString(); });
                Invoke(() => { progress.Value = Convert.ToInt32((((double)(i + 1) / (double)uuidList.Count) * 100.0)); });

                string uuid = uuidList[i];
                KeysTsv[] keyInfo = KeysTsv.LookupKey(uuid);
                foreach (KeysTsv k in keyInfo)
                {
                    McCrypt.Keys.AddKey(k.KeyId, Encoding.UTF8.GetBytes(k.KeyData), false);
                }

                dynamic productInfo = PlayFab.GetProductInformation(uuid);
                foreach(dynamic content in productInfo.Item.Contents)
                {
                    if (content.Type == "skinbinary" || content.Type == "personabinary")
                        urlList.Add(content.Url.ToString());

                    if(content.Type == "resourcebinary") 
                    {
                        foreach(KeysTsv key in keyInfo) // Check you have keys ...
                        {
                            if(!key.KeyType.StartsWith("skin") && !key.KeyType.StartsWith("persona"))
                            {
                                urlList.Add(content.Url.ToString()); // if you do, add resource binary to the download list as well
                            }
                        }
                    }
                }
            }

            // download everything. 
            string downloadFolder = CreateTemporaryFolder();
            Directory.CreateDirectory(downloadFolder);

            List<string> zipList = new List<string>();
            for(int i = 0; i < urlList.Count; i++)
            {
                double downloadedPercent = (((double)i / (double)urlList.Count) * 100.0);
                double downloadedPercentMax = (((double)(i + 1) / (double)urlList.Count) * 100.0) - downloadedPercent;

                Invoke(() => { status.Text = "Downloading " + (i + 1).ToString() + "/" + urlList.Count.ToString(); });

                string url = urlList[i];

                string filepath = CreateTemporaryFile() + ".zip";
                FileDownloader downloader = new FileDownloader(url, filepath);
                while (!downloader.Finished)
                {
                    double downloadedBytes = (double)downloader.DownloadedBytes;
                    double totalBytes = (double)downloader.TotalBytes;
                    if (totalBytes < 1)
                        totalBytes += 1;

                    int percentage = Convert.ToInt32(downloadedPercent + ((downloadedBytes / totalBytes) * downloadedPercentMax));
                    Invoke(() => { progress.Value = percentage; });
                    Application.DoEvents();
                }
                zipList.Add(filepath);
            }

            // Read zipfiles..

            List<string> decryptList = new List<string>();
            for (int i = 0; i < zipList.Count; i++)
            {
                string zip = zipList[i];
                Invoke(() => { status.Text = "Extracting " + (i+1).ToString() + "/" + zipList.Count.ToString(); });
                Invoke(() => { progress.Value = Convert.ToInt32((((double)(i + 1) / (double)zipList.Count) * 100.0)); });

                try
                {
                    ZipArchive outerZip = ZipFile.OpenRead(zip);
                    foreach (ZipArchiveEntry innerZip in outerZip.Entries)
                    {
                        if (Path.GetExtension(innerZip.FullName) == ".zip")
                        {
                            ZipArchive packZip = new ZipArchive(innerZip.Open());
                            string zExt = CreateTemporaryFolder();
                            packZip.ExtractToDirectory(zExt);
                            decryptList.Add(zExt);
                            packZip.Dispose();
                        }
                    }
                    outerZip.Dispose();
                }
                catch (Exception)
                {
                    continue;
                }
            }

            // Decrypt contents!
            for (int i = 0; i < decryptList.Count; i++)
            {
                string decrypt = decryptList[i];

                string manifestFile = Path.Combine(decrypt, "manifest.json");
                string levelDatFile = Path.Combine(decrypt, "level.dat");
                string skinsJsonFile = Path.Combine(decrypt, "skins.json");
                
                Invoke(() => { status.Text = "Decrypting " + (i+1).ToString() + "/" + decryptList.Count.ToString(); });
                Invoke(() => { progress.Value = Convert.ToInt32((((double)(i + 1) / (double)decryptList.Count) * 100.0)); });

                Marketplace.DecryptContents(decrypt);

                if (File.Exists(levelDatFile))
                    Marketplace.CrackLevelDat(levelDatFile);

                if (File.Exists(skinsJsonFile))
                    Marketplace.CrackSkinsJson(skinsJsonFile);


                string segment = "";
                string ext = "";
                if (File.Exists(levelDatFile))
                {
                    segment += " (world)";
                    ext += ".mctemplate";
                }
                else if (File.Exists(skinsJsonFile))
                {
                    segment += " (skins)";
                    ext += ".mcpack";
                }
                else
                {
                    segment += " (resourcepack)";
                    ext += ".mcpack";
                }

                string name = EscapeFilename(Manifest.ReadName(manifestFile) + segment);
                
                Directory.CreateDirectory("output");
                string outFolder = Path.Combine("output", name);
                while (File.Exists(outFolder + ext))
                {
                    outFolder += "_";
                }
                ZipFile.CreateFromDirectory(decrypt, outFolder + ext, CompressionLevel.NoCompression, false);
                
            }

            DeleteTempFiles();

            Invoke(() => { status.Text = "Waiting..."; });
            Invoke(() => { progress.Value = 0; });

            Invoke(() => { dl.Enabled = true; });
        }

        private void dl_Click(object sender, EventArgs e)
        {
            Task.Run(DownloadSelected);
        }

        private void search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)System.Windows.Forms.Keys.Return)
            {
                e.Handled = true;
                _searchFor = search.Text;

                if (!search.ReadOnly && !_searching)
                    Task.Run(DoSearch);
            }
        }

        private void options_Scroll(object sender, ScrollEventArgs e)
        {
            Task.Run(DoSearch);
        }

        private void options_SelectionChanged(object sender, EventArgs e)
        {
            if (_searching)
                return;

            foreach(DataGridViewRow row in options.SelectedRows)
            {
                row.Cells[0].Value = true;
            }
        }

    }
}