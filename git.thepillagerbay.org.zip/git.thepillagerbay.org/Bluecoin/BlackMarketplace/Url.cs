﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackMarketplace
{
    public class Url
    {
        private static List<Url> marketplaceItems = new List<Url>();
        public static Url[] Items
        {
            get
            {
                return marketplaceItems.ToArray();
            }
        }

        public Url(string contentId, string urlId, string urlType, string url)
        {
            this.ContentId = contentId;
            this.UrlId = urlId;
            this.UrlType = urlType;
            this.UrlData = url;
            marketplaceItems.Add(this);

        }

        public string ContentId;
        public string UrlId;
        public string UrlType;
        public string UrlData;
    }
}
