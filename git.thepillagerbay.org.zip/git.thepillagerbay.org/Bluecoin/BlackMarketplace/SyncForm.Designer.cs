﻿namespace BlackMarketplace
{
    partial class SyncForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SyncForm));
            this.label3 = new System.Windows.Forms.Label();
            this.keysTsv = new System.Windows.Forms.TextBox();
            this.sync = new System.Windows.Forms.Button();
            this.progress = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Keys.tsv";
            // 
            // keysTsv
            // 
            this.keysTsv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.keysTsv.Location = new System.Drawing.Point(89, 9);
            this.keysTsv.Name = "keysTsv";
            this.keysTsv.Size = new System.Drawing.Size(465, 23);
            this.keysTsv.TabIndex = 6;
            // 
            // sync
            // 
            this.sync.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sync.Location = new System.Drawing.Point(12, 57);
            this.sync.Name = "sync";
            this.sync.Size = new System.Drawing.Size(542, 23);
            this.sync.TabIndex = 8;
            this.sync.Text = "Sync";
            this.sync.UseVisualStyleBackColor = true;
            this.sync.Click += new System.EventHandler(this.sync_Click);
            // 
            // progress
            // 
            this.progress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.progress.AutoSize = true;
            this.progress.Location = new System.Drawing.Point(12, 39);
            this.progress.Name = "progress";
            this.progress.Size = new System.Drawing.Size(57, 15);
            this.progress.TabIndex = 9;
            this.progress.Text = "Waiting...";
            // 
            // SyncForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 92);
            this.Controls.Add(this.progress);
            this.Controls.Add(this.sync);
            this.Controls.Add(this.keysTsv);
            this.Controls.Add(this.label3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(582, 131);
            this.Name = "SyncForm";
            this.Text = "Sync";
            this.Load += new System.EventHandler(this.SyncForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label3;
        private TextBox keysTsv;
        private Button sync;
        private Label progress;
    }
}