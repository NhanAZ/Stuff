﻿using System.Net;

namespace BlackMarketplace
{
#pragma warning disable SYSLIB0014 // Type or member is obsolete
    class McClient : WebClient
    {
        protected override WebRequest GetWebRequest(Uri address)
        {
            HttpWebRequest? request = base.GetWebRequest(address) as HttpWebRequest;
            if (request == null)
                return null;
            request.AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip | DecompressionMethods.Brotli;
            return request;
         
        }
    }
}
