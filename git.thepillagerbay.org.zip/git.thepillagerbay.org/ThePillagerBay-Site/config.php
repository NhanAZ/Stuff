<?php
$dbname = 'tpb';
$dbuser = 'root';
$dbpass = 'EXAMPLECREDS';
$dbhost = '127.0.0.1';
?>
